﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Class_07_Practice.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string Email { get; set; }

        //
        public virtual CustomerAddress CustomerAddress { get; set; }
        public virtual ICollection<CustomerPhoto> CustomerPhotos { get; set; }
    }

    public class CustomerAddress
    {
        [Key,ForeignKey("Customer")]
        public int CustomerId { get; set; }
        public string Address { get; set; }
        public string PostCode { get; set; }

        //
        public virtual Customer Customer { get; set; }
    }

    public class CustomerPhoto
    {
        [Key, ForeignKey("Customer")]
        public int CustomerId { get; set; }
        public string Image { get; set; }

        //
        public virtual Customer Customer { get; set; }
    }
    public class CustomerDbContext: DbContext
    {
        public CustomerDbContext(DbContextOptions<CustomerDbContext>options):base(options)
        {
            
        }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<CustomerAddress> CustomerAddresses { get; set; }
        public DbSet<CustomerPhoto> CustomerPhotos { get; set; }
    }

}
