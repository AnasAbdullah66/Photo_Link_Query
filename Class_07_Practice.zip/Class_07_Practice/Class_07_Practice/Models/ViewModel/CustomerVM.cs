﻿namespace Class_07_Practice.Models.ViewModel
{
    public class CustomerVM
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string PostCode { get; set; }
        public IFormFile Image { get; set; }
        public string ImagePath { get; set; }
    }
}
