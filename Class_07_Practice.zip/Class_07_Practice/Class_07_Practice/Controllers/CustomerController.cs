﻿using Class_07_Practice.Models;
using Class_07_Practice.Models.ViewModel;
using Microsoft.AspNetCore.Mvc;

namespace Class_07_Practice.Controllers
{
    public class CustomerController : Controller
    {
        private readonly CustomerDbContext _db;
        private readonly IWebHostEnvironment _env;
        public CustomerController(CustomerDbContext db, IWebHostEnvironment env)
        {
            _db = db;
            _env = env;
        }
        public IActionResult Index()
        {
            var customerInfo = (from c in _db.Customers
                                join ca in _db.CustomerAddresses on c.CustomerId equals ca.CustomerId
                                join cp in _db.CustomerPhotos on c.CustomerId equals cp.CustomerId
                                select new CustomerVM
                                {
                                    CustomerId = c.CustomerId,
                                    CustomerName = c.CustomerName,
                                    Email = c.Email,
                                    Address = ca.Address,
                                    PostCode = ca.PostCode,
                                    ImagePath = cp.Image
                                }).ToList();
            return View(customerInfo);
        }

        public IActionResult Create()
        {
            return View();

        }

        [HttpPost]
        public IActionResult Create(CustomerVM customer)
        {
            //image
            string webroot = _env.WebRootPath;
            string folder = "Images";
            string imageFileName = Path.GetFileName(customer.Image.FileName);
            string fileToWrite = Path.Combine(webroot, folder, imageFileName);
            string newFilePath = Path.Combine("Images", imageFileName);

            //if (ModelState.IsValid)
            //{
            using (var steam = new FileStream(fileToWrite, FileMode.Create))
            {
                customer.Image.CopyTo(steam);

            }


            Customer c = new Customer
            {
                CustomerName = customer.CustomerName,
                Email = customer.Email
            };

            //
            //_db.Customers.Add(c); // Add the Customer object to the DbContext and save changes
            //_db.SaveChanges();
            //

            CustomerAddress ca = new CustomerAddress
            {
                /*CustomerId = c.CustomerId,*///
                Address = customer.Address,
                PostCode = customer.PostCode,
                Customer = c
            };
            CustomerPhoto cp = new CustomerPhoto
            {
                Customer = c,
                Image = newFilePath
            };
            _db.CustomerAddresses.Add(ca);
            _db.CustomerPhotos.Add(cp);
            _db.SaveChanges();
            return RedirectToAction("Index");
        }
        //        return View(customer);
        //}


        //public IActionResult Create(CustomerVM customer)
        //{
        //    if (customer == null || customer.Image == null)
        //    {
        //        return View(customer);
        //    }

        //    // Validate image file format
        //    var validImageTypes = new[] { "image/jpeg", "image/png", "image/gif" };
        //    if (!validImageTypes.Contains(customer.Image.ContentType))
        //    {
        //        ModelState.AddModelError("Image", "Please choose a JPEG, PNG, or GIF image file.");
        //        return View(customer);
        //    }

        //    // Save image to file system
        //    string webroot = _env.WebRootPath;
        //    string folder = "Images";
        //    string imageFileName = Path.GetFileName(customer.Image.FileName);
        //    string fileToWrite = Path.Combine(webroot, folder, imageFileName);
        //    string newFilePath = Path.Combine("Images", imageFileName);
        //    using (var stream = new FileStream(fileToWrite, FileMode.Create))
        //    {
        //        customer.Image.CopyTo(stream);
        //    }

        //    // Create customer and related entities in database
        //    var c = new Customer
        //    {
        //        CustomerName = customer.CustomerName,
        //        Email = customer.Email
        //    };
        //    var ca = new CustomerAddress
        //    {
        //        Address = customer.Address,
        //        PostCode = customer.PostCode,
        //        Customer = c
        //    };
        //    var cp = new CustomerPhoto
        //    {
        //        Image = newFilePath,
        //        Customer = c
        //    };
        //    _db.CustomerAddresses.Add(ca);
        //    _db.CustomerPhotos.Add(cp);
        //    _db.SaveChanges();

        //    return RedirectToAction("Index");
        //}

        public IActionResult Edit(int? id)
        {
            if (id is not null)
            {
                var cust =_db.Customers.FirstOrDefault(x=>x.CustomerId == id);
                var ca = _db.CustomerAddresses.FirstOrDefault(x => x.CustomerId == id);
                var cp = _db.CustomerPhotos.FirstOrDefault(x => x.CustomerId == id);
                CustomerVM vm = new CustomerVM
                {
                    CustomerId = cust.CustomerId,
                    CustomerName = cust.CustomerName,
                    Email = cust.Email,
                    Address = ca.Address,
                    PostCode = ca.PostCode,
                    ImagePath = cp.Image
                };
                return View(vm);
            }
            return View();
        }

        [HttpPost]
        public IActionResult Edit(CustomerVM vm)
        {
            //if (ModelState.IsValid)
            //{
                if (vm.Image != null)
                {
                    string newFileName = Guid.NewGuid().ToString() + "_" + vm.Image.FileName;
                    string newFilePath = Path.Combine("Images", newFileName);
                    string file = Path.Combine(_env.WebRootPath, newFilePath);
                    vm.Image.CopyTo(new FileStream(file, FileMode.Create));

                    Customer c = new Customer
                    {
                        CustomerId = vm.CustomerId,
                        CustomerName = vm.CustomerName,
                        Email = vm.Email
                    };

                    CustomerAddress ca = new CustomerAddress
                    {
                        CustomerId = vm.CustomerId,
                        Address = vm.Address,
                        PostCode = vm.PostCode,
                        Customer = c
                    };
                    CustomerPhoto cp = new CustomerPhoto
                    {
                        CustomerId = vm.CustomerId,
                        Customer = c,
                        Image = newFilePath
                    };
                    _db.Entry(c).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    _db.Entry(ca).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    _db.Entry(cp).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    _db.SaveChanges();
                    return RedirectToAction("Index");
                }
                else
                {
                    Customer c = new Customer
                    {
                        CustomerId = vm.CustomerId,
                        CustomerName = vm.CustomerName,
                        Email = vm.Email
                    };

                    CustomerAddress ca = new CustomerAddress
                    {
                        CustomerId = vm.CustomerId,
                        Address = vm.Address,
                        PostCode = vm.PostCode,
                        Customer = c
                    };
                    _db.Entry(c).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    _db.Entry(ca).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    _db.SaveChanges();
                    return RedirectToAction("Index");
                }

            }

        //    return View();
        //}

        //public IActionResult Edit(CustomerVM vm)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        Customer c = new Customer
        //        {
        //            CustomerId = vm.CustomerId,
        //            CustomerName = vm.CustomerName,
        //            Email = vm.Email
        //        };

        //        CustomerAddress ca = new CustomerAddress
        //        {
        //            CustomerId = vm.CustomerId,
        //            Address = vm.Address,
        //            PostCode = vm.PostCode,
        //            Customer = c
        //        };

        //        // Get the customer photo record from the database
        //        CustomerPhoto cp = _db.CustomerPhotos.FirstOrDefault(cp => cp.CustomerId == vm.CustomerId);

        //        if (vm.Image != null)
        //        {
        //            // Delete the old image file if it exists
        //            if (cp != null && !string.IsNullOrEmpty(cp.Image))
        //            {
        //                string oldFilePath = Path.Combine(_env.WebRootPath, cp.Image);
        //                if (System.IO.File.Exists(oldFilePath))
        //                {
        //                    System.IO.File.Delete(oldFilePath);
        //                }
        //            }

        //            // Save the new image file
        //            string newFileName = Guid.NewGuid().ToString() + "_" + vm.Image.FileName;
        //            string newFilePath = Path.Combine("Images", newFileName);
        //            string file = Path.Combine(_env.WebRootPath, newFilePath);
        //            vm.Image.CopyTo(new FileStream(file, FileMode.Create));

        //            // Update the customer photo record in the database
        //            if (cp == null)
        //            {
        //                cp = new CustomerPhoto
        //                {
        //                    CustomerId = vm.CustomerId,
        //                    Customer = c,
        //                    Image = newFilePath
        //                };
        //                _db.CustomerPhotos.Add(cp);
        //            }
        //            else
        //            {
        //                cp.Image = newFilePath;
        //                _db.Entry(cp).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
        //            }
        //        }
        //        else if (cp != null && !string.IsNullOrEmpty(cp.Image))
        //        {
        //            // Use the existing image file if no new image is uploaded
        //            c.CustomerPhotos = new List<CustomerPhoto> { cp };
        //        }

        //        // Save changes to the database
        //        _db.Entry(c).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
        //        _db.Entry(ca).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
        //        _db.SaveChanges();

        //        return RedirectToAction("Index");
        //    }

        //    return View();
        //}

    }

}
